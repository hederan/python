# SentimentAnalysis
This is a sentiment Analysis project developed on Python Flask Framework.
It has a full fledged login, registation module with sessins. The login database is deployed on Xampp server.
Database: Users. 
table name: users.
Fields- name, email(unique), password.

To develop this project, you must also have a "Twitter Developers Account" for tweepy. 
It takes in a keyword, and the number of Tweets from a HTML form.
The output is The sentiment analyzed, and a Pie Chart related to it. 
